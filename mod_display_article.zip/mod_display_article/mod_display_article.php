<?php

include('helper.php');

$articleid = $params->get('articleid');
$length = $params->get('length');


$articleclass= new getArticle($articleid, $length);
$articlecontent = $articleclass->getContent();

echo '<div class = "moduletable' . $params->get('modclasssuffix') . '">';
echo $articlecontent;
echo '</div>';




?>