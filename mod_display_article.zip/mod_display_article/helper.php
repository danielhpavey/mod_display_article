<?php

class getArticle {
	var $articleid;
	var $length;
		
	
function __construct($articleid, $length){
	$this->article = $articleid;
	$this->length = $length;
}
	
	
function getContent(){
	
	$app = JFactory::getApplication();
	$prefix = $app->getCfg('dbprefix');

	$q = 'select introtext from ' . $prefix . 'content where id = ' . $this->article ;
	
	$r = mysql_result(mysql_query($q), 0,0);
	 
	
	return $r;
}

}

?>
